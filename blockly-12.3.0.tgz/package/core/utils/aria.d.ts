/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * ARIA role values.
 * Copied from Closure's goog.a11y.aria.Role
 */
export declare enum Role {
    GROUP = "group",
    LISTBOX = "listbox",
    MENU = "menu",
    MENUITEM = "menuitem",
    OPTION = "option",
    PRESENTATION = "presentation",
    TREE = "tree",
    TREEITEM = "treeitem",
    SEPARATOR = "separator",
    STATUS = "status",
    IMAGE = "image",
    FIGURE = "figure",
    BUTTON = "button",
    CHECKBOX = "checkbox",
    TEXTBOX = "textbox",
    COMBOBOX = "combobox",
    SPINBUTTON = "spinbutton",
    REGION = "region"
}
/**
 * ARIA states and properties.
 * Copied from Closure's goog.a11y.aria.State
 */
export declare enum State {
    ACTIVEDESCENDANT = "activedescendant",
    DISABLED = "disabled",
    EXPANDED = "expanded",
    INVALID = "invalid",
    LABEL = "label",
    LABELLEDBY = "labelledby",
    LEVEL = "level",
    POSINSET = "posinset",
    SELECTED = "selected",
    SETSIZE = "setsize",
    VALUEMAX = "valuemax",
    VALUEMIN = "valuemin",
    VALUENOW = "valuenow",
    LIVE = "live",
    HIDDEN = "hidden",
    ROLEDESCRIPTION = "roledescription",
    OWNS = "owns",
    HASPOPUP = "haspopup",
    CONTROLS = "controls",
    CHECKED = "checked"
}
/**
 * Updates the specific role for the specified element.
 *
 * @param element The element whose ARIA role should be changed.
 * @param roleName The new role for the specified element, or null if its role
 *     should be cleared.
 */
export declare function setRole(element: Element, roleName: Role | null): void;
/**
 * Returns the ARIA role of the specified element, or null if it either doesn't
 * have a designated role or if that role is unknown.
 *
 * @param element The element from which to retrieve its ARIA role.
 * @returns The ARIA role of the element, or null if undefined or unknown.
 */
export declare function getRole(element: Element): Role | null;
/**
 * Sets the specified ARIA state by its name and value for the specified
 * element.
 *
 * Note that the type of value is not validated against the specific type of
 * state being changed, so it's up to callers to ensure the correct value is
 * used for the given state.
 *
 * @param element The element whose ARIA state may be changed.
 * @param stateName The state to change.
 * @param value The new value to specify for the provided state.
 */
export declare function setState(element: Element, stateName: State, value: string | boolean | number | string[]): void;
/**
 * Clears the specified ARIA state by removing any related attributes from the
 * specified element that have been set using setState().
 *
 * @param element The element whose ARIA state may be changed.
 * @param stateName The state to clear from the provided element.
 */
export declare function clearState(element: Element, stateName: State): void;
/**
 * Returns a string representation of the specified state for the specified
 * element, or null if it's not defined or specified.
 *
 * Note that an explicit set state of 'null' will return the 'null' string, not
 * the value null.
 *
 * @param element The element whose state is being retrieved.
 * @param stateName The state to retrieve.
 * @returns The string representation of the requested state for the specified
 *     element, or null if not defined.
 */
export declare function getState(element: Element, stateName: State): string | null;
/**
 * Softly requests that the specified text be read to the user if a screen
 * reader is currently active.
 *
 * This relies on a centrally managed ARIA live region that should not interrupt
 * existing announcements (that is, this is what's considered a polite
 * announcement).
 *
 * Callers should use this judiciously. It's often considered bad practice to
 * over announce information that can be inferred from other sources on the
 * page, so this ought to only be used when certain context cannot be easily
 * determined (such as dynamic states that may not have perfect ARIA
 * representations or indications).
 *
 * @param text The text to politely read to the user.
 */
export declare function announceDynamicAriaState(text: string, options?: {
    assertiveness: string;
    role: Role | null;
}): void;
//# sourceMappingURL=aria.d.ts.map